reviewer: Codex Game Studio seed review
date: 2026-06-17
source-link: https://dev.epicgames.com/documentation/en-us/unreal-engine/
engine: unreal
version-reviewed: 5.5
tags: unreal,audio,sound,music,sfx
roles: audio-director,sound-designer,gameplay-programmer
workflows: prototype,bugfix,architecture-review,qa-plan

# Unreal Audio Module Reference

## Purpose

Music, SFX, voice, routing, mixers, spatial audio, and subtitle/accessibility coordination.

## Guidance

- Select this file only for audio-related tasks.
- Keep implementation guidance scoped to Unreal project files and validation commands.
- Include performance, accessibility, and content-pipeline risks when they apply.

## Validation

- Prefer project-local engine commands and Codex Game Studio project validation before readiness claims.
- Record unknown version-specific behavior as a risk instead of presenting it as confirmed.
- Keep this reference selected by relevance; do not load every engine reference for one task.
