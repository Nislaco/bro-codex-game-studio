---
name: cgs-scope-check
description: Use for scope check tasks that assess whether requested work fits the milestone and propose cuts, deferrals, or safer slices; produce verification evidence, changed or proposed files, and handoff boundaries.
model: bitrouter/auto
model_reasoning_effort: medium
argument-hint: Describe the scope-check objective, target files/assets, constraints, and verification evidence.
primary-agent: producer
tool-policy: read/edit/shell/tests/git as needed within the repository write policy
isolation: repository-root; no init-time generated prompt bodies
source-reference: .claude/skills/scope-check/SKILL.md
source-hash: f91150df11aadf32cfa64a1476c608396e12eeeba9aca03836c52299f3a0efa0
user-invocable: true
---

# Codex Game Studio Scope Check

Use this skill for scope check work in Template Game.

## Objective

Assess whether requested work fits the milestone and propose cuts, deferrals, or safer slices.

## Inputs

- AGENTS.md
- .codex/studio.json
- task-relevant files named by the user or task record
- production/timeline.md
- production/session-state/active.md

## Arguments

- Objective or user request.
- Target files, scenes, assets, or docs.
- Constraints, deadlines, acceptance criteria, and verification command when known.

## Procedure

1. Clarify the requested assess whether requested work fits the milestone and propose cuts, deferrals, or safer slices. and identify the current project stage.
2. Collect evidence for Scope Fit, Cut Option, Deferral.
3. Break the work into owner-sized tasks with dependencies, risks, and acceptance checks.
4. Produce the requested artifact or review with clear file paths and verification evidence.

## Write Targets

- production/

## Output Contract

- Summary
- Scope Fit
- Cut Option
- Deferral
- Recommendation
- Risks
- Changed files or proposed files
- Verification evidence
- Next owner or decision

## Quality Gates

- Scope Fit
- Cut Option
- Deferral
- Recommendation
- Scope remains bounded to the current task and project stage.
- Report labels unverified assumptions separately from evidence.

## Decision Gates

- Continue only when the expected output can be verified or clearly labeled as a plan.
- Escalate to producer or qa-playtester when scope, ownership, or acceptance evidence is ambiguous.
- Stop before broad rewrites, generated prompt mirrors, or hidden lifecycle behavior.

## Handoff

Report changed files, verification evidence, remaining risks, and the next owner or decision. Do not imply hidden hooks or autonomous background work.
