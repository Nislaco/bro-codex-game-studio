---
name: cgs-test-flakiness
description: Use for test flakiness tasks that diagnose flaky tests by isolating timing, randomness, ordering, environment, and cleanup causes; produce verification evidence, changed or proposed files, and handoff boundaries.
model: bitrouter/auto
model_reasoning_effort: high
argument-hint: Describe the test-flakiness objective, target files/assets, constraints, and verification evidence.
primary-agent: qa-playtester
tool-policy: read/edit/shell/tests/git as needed within the repository write policy
isolation: repository-root; no init-time generated prompt bodies
source-reference: .claude/skills/test-flakiness/SKILL.md
source-hash: 3849299d9c0b667a2974157a2ce692892bcef475b87e0c20ad029b22f335b805
user-invocable: true
---

# Codex Game Studio Test Flakiness

Use this skill for test flakiness work in Template Game.

## Objective

Diagnose flaky tests by isolating timing, randomness, ordering, environment, and cleanup causes.

## Inputs

- AGENTS.md
- .codex/studio.json
- task-relevant files named by the user or task record
- design/gdd.md
- production/session-state/active.md
- tests/

## Arguments

- Objective or user request.
- Target files, scenes, assets, or docs.
- Constraints, deadlines, acceptance criteria, and verification command when known.

## Procedure

1. Clarify the requested diagnose flaky tests by isolating timing, randomness, ordering, environment, and cleanup causes. and identify the current project stage.
2. Collect evidence for Failure Pattern, Isolation, Root Cause.
3. Run or define the focused validation loop before reporting conclusions.
4. Produce the requested artifact or review with clear file paths and verification evidence.

## Write Targets

- tests/
- production/session-state/
- prototypes/

## Output Contract

- Summary
- Failure Pattern
- Isolation
- Root Cause
- Stabilization
- Risks
- Changed files or proposed files
- Verification evidence
- Next owner or decision

## Quality Gates

- Failure Pattern
- Isolation
- Root Cause
- Stabilization
- Scope remains bounded to the current task and project stage.
- Report labels unverified assumptions separately from evidence.

## Decision Gates

- Continue only when the expected output can be verified or clearly labeled as a plan.
- Escalate to producer or qa-playtester when scope, ownership, or acceptance evidence is ambiguous.
- Stop before broad rewrites, generated prompt mirrors, or hidden lifecycle behavior.

## Handoff

Report changed files, verification evidence, remaining risks, and the next owner or decision. Do not imply hidden hooks or autonomous background work.
