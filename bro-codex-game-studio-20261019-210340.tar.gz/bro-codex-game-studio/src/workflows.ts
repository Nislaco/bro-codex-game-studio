import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { createCodexStudioSession, type CodexStudioPhase } from "./codex-session.js";
import { selectContextEntries } from "./context-manifest.js";
import { renderCodexPrompt } from "./codex-prompts.js";
import type { EngineId } from "./engines.js";
import { renderContextContract } from "./prompt-context.js";
import type { StudioProjectState } from "./projects.js";
import { isStudioRoleId, type StudioRoleId } from "./roles.js";
import { evaluateStudioRunEligibility } from "./studio-policy.js";
import { engineReferenceContextRequests } from "./engine-reference.js";
import { renderSelectedTemplates, type TemplateId } from "./templates.js";
import { findCustomRole, findCustomWorkflow, projectRelativePath, renderCustomRolePrompt, type CustomWorkflowDefinition } from "./customization.js";
import { isReasoningEffort, modelTierForModel, type CodexModelName, type ModelTier, type ReasoningEffort } from "./prompt-surface-metadata.js";

export type WorkflowCategory =
  | "onboarding-discovery"
  | "design-architecture"
  | "implementation-planning"
  | "qa-testing"
  | "release-hotfix"
  | "localization-accessibility"
  | "team-coordination";

export type WorkflowId =
  | "vertical-slice"
  | "bugfix"
  | "playtest"
  | "market-analysis"
  | "analytics-setup"
  | "engine-setup"
  | "game-concept"
  | "design-review-concept"
  | "art-bible"
  | "map-systems"
  | "design-system"
  | "design-review"
  | "review-all-gdds"
  | "consistency-check"
  | "create-architecture"
  | "control-manifest"
  | "accessibility-doc"
  | "entity-inventory"
  | "asset-spec"
  | "ux-design"
  | "ux-review"
  | "test-setup"
  | "implement"
  | "code-review"
  | "bug-report"
  | "retrospective"
  | "team-feature"
  | "scope-check"
  | "balance-check"
  | "asset-audit"
  | "playtest-polish"
  | "team-polish"
  | "patch-notes"
  | "changelog"
  | "launch-checklist"
  | "design-spec"
  | "game-feel-tuning"
  | "art-direction"
  | "ui-ux-review"
  | "production-milestone"
  | "handoff"
  | "review"
  | "ship-check"
  | "onboard"
  | "brainstorm"
  | "prototype"
  | "architecture-decision"
  | "architecture-review"
  | "create-epics"
  | "create-stories"
  | "sprint-plan"
  | "sprint-status"
  | "story-readiness"
  | "story-done"
  | "qa-plan"
  | "regression-suite"
  | "security-audit"
  | "perf-profile"
  | "release-checklist"
  | "hotfix"
  | "localization-plan"
  | "godot-implementation";

export type WorkflowDefinition = {
  id: WorkflowId;
  role: StudioRoleId;
  phase: Extract<CodexStudioPhase, "plan" | "implement" | "review" | "ship">;
  objective: string;
  category: WorkflowCategory;
  gapCoverage: string[];
  file: `.codex/workflows/${string}.md`;
  contextFiles: string[];
  templateIds?: TemplateId[];
  cliAlias?: string;
  cliAliases?: string[];
  modelTier: ModelTier;
  model: CodexModelName;
  modelReasoningEffort: ReasoningEffort;
};

type WorkflowInput = Omit<WorkflowDefinition, "file" | "contextFiles" | "modelTier"> & {
  extraContextFiles?: string[];
};

function workflow(input: WorkflowInput): WorkflowDefinition {
  const modelTier = modelTierForModel(input.model);
  if (!modelTier) throw new Error(`Workflow ${input.id} has an invalid or unregistered model: ${input.model}`);
  if (!isReasoningEffort(input.modelReasoningEffort)) throw new Error(`Workflow ${input.id} has an invalid or missing model reasoning effort`);
  return {
    ...input,
    file: `.codex/workflows/${input.id}.md`,
    contextFiles: ["AGENTS.md", ".codex/studio.json", `.codex/workflows/${input.id}.md`, ...(input.extraContextFiles ?? [])],
    modelTier
  };
}

export const workflowRegistry: Record<WorkflowId, WorkflowDefinition> = {
  "vertical-slice": workflow({
    id: "vertical-slice",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "producer",
    phase: "plan",
    category: "implementation-planning",
    gapCoverage: ["vertical-slice planning", "milestone decomposition"],
    objective: "Create a bounded vertical-slice plan with tasks, risks, and verification gates.",
    extraContextFiles: ["design/gdd.md"]
  }),
  bugfix: workflow({
    id: "bugfix",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "gameplay-programmer",
    phase: "implement",
    category: "release-hotfix",
    gapCoverage: ["defect triage", "bounded implementation repair"],
    objective: "Reproduce, fix, verify, and document a defect with bounded scope."
  }),
  playtest: workflow({
    id: "playtest",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "qa-playtester",
    phase: "review",
    category: "qa-testing",
    gapCoverage: ["playtest reporting", "reproducible issue capture"],
    objective: "Inspect the current build, report reproducible playtest issues, and separate blockers from warnings.",
    templateIds: ["playtest_report", "test_evidence"]
  }),
  "market-analysis": workflow({
    id: "market-analysis",
    model: "bitrouter/auto",
    modelReasoningEffort: "low",
    role: "market-analyst",
    phase: "plan",
    category: "onboarding-discovery",
    gapCoverage: ["market discovery", "competitor positioning"],
    objective: "Analyze audience, competitors, positioning, pricing, and market risks for the current project.",
    extraContextFiles: ["docs/market-overview.md"],
    templateIds: ["market_analysis", "pitch_document"],
    cliAlias: "market"
  }),
  "analytics-setup": workflow({
    id: "analytics-setup",
    model: "bitrouter/auto",
    modelReasoningEffort: "low",
    role: "data-scientist",
    phase: "plan",
    category: "onboarding-discovery",
    gapCoverage: ["analytics onboarding", "success metric planning"],
    objective: "Define analytics events, success metrics, experiment plans, and evidence loops for the current project.",
    templateIds: ["analytics_setup"],
    cliAlias: "analytics"
  }),
  "engine-setup": workflow({
    id: "engine-setup",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "technical-director",
    phase: "plan",
    category: "onboarding-discovery",
    gapCoverage: ["engine setup", "project configuration"],
    objective: "Confirm the selected engine, version, repository structure, run commands, and first validation path before design or implementation work proceeds.",
    templateIds: ["engine_setup", "project_config"],
    cliAlias: "engine-setup"
  }),
  "game-concept": workflow({
    id: "game-concept",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "creative-director",
    phase: "plan",
    category: "onboarding-discovery",
    gapCoverage: ["game concept", "core pillars"],
    objective: "Turn the game idea into a concise concept with player fantasy, pillars, target audience, scope tier, and initial risks.",
    templateIds: ["gdd", "pitch_document", "player_journey"],
    cliAlias: "game-concept"
  }),
  "design-review-concept": workflow({
    id: "design-review-concept",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "senior-game-designer",
    phase: "review",
    category: "design-architecture",
    gapCoverage: ["concept review", "pillar and scope validation"],
    objective: "Review the concept for coherent player promise, pillars, audience fit, production scope, and design risks before deeper systems work.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["gdd", "risk_register"],
    cliAlias: "design-review-concept"
  }),
  "art-bible": workflow({
    id: "art-bible",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "senior-game-artist",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["art bible", "visual production constraints"],
    objective: "Define the art bible with visual pillars, references, asset constraints, style rules, production risks, and review criteria.",
    templateIds: ["art_bible", "risk_register"],
    cliAlias: "art-bible"
  }),
  "map-systems": workflow({
    id: "map-systems",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "systems-designer",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["systems map", "system dependency mapping"],
    objective: "Map core gameplay, economy, progression, content, UI, and technical systems with dependencies, owners, and validation signals.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["gdd", "technical_design", "architecture_traceability"],
    cliAlias: "map-systems"
  }),
  "design-system": workflow({
    id: "design-system",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "systems-designer",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["system design", "per-system GDD"],
    objective: "Author or update a system design with player-facing rules, data model, edge cases, dependencies, tuning hooks, and acceptance criteria.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["feature_spec", "economy_model", "difficulty_curve"],
    cliAlias: "design-system"
  }),
  "design-review": workflow({
    id: "design-review",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "senior-game-designer",
    phase: "review",
    category: "design-architecture",
    gapCoverage: ["design review", "scope and consistency review"],
    objective: "Review design docs for player promise, systemic consistency, production scope, edge cases, and handoff readiness.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["gdd", "risk_register", "handoff"],
    cliAlias: "design-review"
  }),
  "review-all-gdds": workflow({
    id: "review-all-gdds",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "senior-game-designer",
    phase: "review",
    category: "design-architecture",
    gapCoverage: ["GDD review", "cross-document consistency"],
    objective: "Review all GDD and design artifacts for contradictions, missing systems, stale assumptions, and implementation blockers.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["gdd", "handoff", "risk_register"],
    cliAlias: "review-all-gdds"
  }),
  "consistency-check": workflow({
    id: "consistency-check",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "studio-orchestrator",
    phase: "review",
    category: "team-coordination",
    gapCoverage: ["consistency check", "cross-surface contradiction review"],
    objective: "Check design, production, architecture, UI, and validation surfaces for contradictions, missing owners, and stale assumptions.",
    extraContextFiles: ["design/gdd.md", "production/timeline.md"],
    templateIds: ["handoff", "risk_register"],
    cliAlias: "consistency-check"
  }),
  "create-architecture": workflow({
    id: "create-architecture",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "technical-director",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["architecture creation", "technical boundaries"],
    objective: "Create technical architecture with engine modules, data flow, integration points, risk areas, and verification strategy.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["technical_design", "architecture_traceability", "adr"],
    cliAlias: "create-architecture"
  }),
  "control-manifest": workflow({
    id: "control-manifest",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "ui-ux-designer",
    phase: "plan",
    category: "localization-accessibility",
    gapCoverage: ["control manifest", "input mapping documentation"],
    objective: "Document controls, input devices, remapping requirements, UI prompts, accessibility constraints, and verification paths.",
    templateIds: ["ux_spec", "accessibility_requirements", "player_journey"],
    cliAlias: "control-manifest"
  }),
  "accessibility-doc": workflow({
    id: "accessibility-doc",
    model: "bitrouter/auto",
    modelReasoningEffort: "low",
    role: "accessibility-specialist",
    phase: "plan",
    category: "localization-accessibility",
    gapCoverage: ["accessibility documentation", "accommodation requirements"],
    objective: "Document accessibility requirements across visual, audio, motor, cognitive, input, difficulty, and verification concerns.",
    templateIds: ["accessibility_requirements", "ux_spec", "test_plan"],
    cliAlias: "accessibility-doc"
  }),
  "entity-inventory": workflow({
    id: "entity-inventory",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "systems-designer",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["entity inventory", "content entity taxonomy"],
    objective: "Create or update an entity inventory covering gameplay objects, actors, content items, dependencies, ownership, and verification signals.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["gdd", "feature_spec"],
    cliAlias: "entity-inventory"
  }),
  "asset-spec": workflow({
    id: "asset-spec",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "senior-game-artist",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["asset specification", "art production handoff"],
    objective: "Create an implementation-ready asset specification with references, constraints, variants, file expectations, risks, and review criteria.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["art_direction", "art_bible"],
    cliAlias: "asset-spec"
  }),
  "ux-design": workflow({
    id: "ux-design",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "ui-ux-designer",
    phase: "plan",
    category: "localization-accessibility",
    gapCoverage: ["UX design", "player journey and interface specification"],
    objective: "Design player journeys, HUD, menus, interaction states, onboarding, accessibility hooks, and implementation-ready UX artifacts.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["ux_spec", "accessibility_requirements", "player_journey"],
    cliAlias: "ux-design"
  }),
  "ux-review": workflow({
    id: "ux-review",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "ui-ux-designer",
    phase: "review",
    category: "localization-accessibility",
    gapCoverage: ["UX review", "usability risk inspection"],
    objective: "Review UX flows, HUD, menus, onboarding, interaction states, accessibility risks, and handoff readiness with concrete findings.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["ui_ux_review", "ux_spec", "accessibility_requirements"],
    cliAlias: "ux-review"
  }),
  "test-setup": workflow({
    id: "test-setup",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "qa-playtester",
    phase: "plan",
    category: "qa-testing",
    gapCoverage: ["test setup", "QA environment readiness"],
    objective: "Define the test setup for the current feature or milestone, including scenarios, data, environment assumptions, automation hooks, and exit criteria.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["test_plan", "test_evidence"],
    cliAlias: "test-setup"
  }),
  implement: workflow({
    id: "implement",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "gameplay-programmer",
    phase: "implement",
    category: "implementation-planning",
    gapCoverage: ["implementation execution", "bounded feature delivery"],
    objective: "Implement a bounded feature slice from accepted design context with changed files, validation evidence, risks, and handoff notes.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["feature_spec", "test_evidence", "vertical_slice_report"],
    cliAlias: "implement"
  }),
  "code-review": workflow({
    id: "code-review",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "technical-director",
    phase: "review",
    category: "qa-testing",
    gapCoverage: ["code review", "implementation quality gate"],
    objective: "Review code changes for correctness, architecture fit, engine conventions, testing evidence, risk, and release readiness.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["architecture_traceability", "technical_design"],
    cliAlias: "code-review"
  }),
  "bug-report": workflow({
    id: "bug-report",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "qa-playtester",
    phase: "review",
    category: "qa-testing",
    gapCoverage: ["bug reporting", "reproducible defect capture"],
    objective: "Capture a reproducible bug report with expected versus actual behavior, environment, repro steps, evidence, severity, and owner routing.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["playtest_report", "test_evidence"],
    cliAlias: "bug-report"
  }),
  retrospective: workflow({
    id: "retrospective",
    model: "bitrouter/auto",
    modelReasoningEffort: "low",
    role: "producer",
    phase: "review",
    category: "team-coordination",
    gapCoverage: ["retrospective", "learning capture"],
    objective: "Run a milestone or sprint retrospective that records outcomes, misses, risks, follow-ups, and concrete process changes.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["postmortem", "risk_register"],
    cliAlias: "retrospective"
  }),
  "team-feature": workflow({
    id: "team-feature",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "producer",
    phase: "plan",
    category: "team-coordination",
    gapCoverage: ["team feature planning", "cross-discipline coordination"],
    objective: "Plan a cross-discipline feature with owner roles, artifacts, dependencies, risks, implementation slices, and verification gates.",
    extraContextFiles: ["design/gdd.md", "production/timeline.md"],
    templateIds: ["production_milestone", "feature_spec", "sprint_plan"],
    cliAlias: "team-feature"
  }),
  "scope-check": workflow({
    id: "scope-check",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "producer",
    phase: "review",
    category: "team-coordination",
    gapCoverage: ["scope check", "production cutline review"],
    objective: "Review production scope, identify cuts or deferrals, name owner decisions, and preserve the smallest shippable milestone.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["production_milestone", "risk_register"],
    cliAlias: "scope-check"
  }),
  "balance-check": workflow({
    id: "balance-check",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "economy-designer",
    phase: "review",
    category: "design-architecture",
    gapCoverage: ["balance check", "economy and progression risk review"],
    objective: "Review balance, resources, progression, difficulty, exploit risks, and tuning hooks against player goals and telemetry signals.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["economy_model"],
    cliAlias: "balance-check"
  }),
  "asset-audit": workflow({
    id: "asset-audit",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "senior-game-artist",
    phase: "review",
    category: "design-architecture",
    gapCoverage: ["asset audit", "content completeness review"],
    objective: "Audit assets for completeness, style fit, technical constraints, naming, missing variants, and release-blocking production risks.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["art_direction", "art_bible"],
    cliAlias: "asset-audit"
  }),
  "playtest-polish": workflow({
    id: "playtest-polish",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "qa-playtester",
    phase: "review",
    category: "qa-testing",
    gapCoverage: ["playtest polish", "player experience triage"],
    objective: "Review playtest feedback and current build evidence to prioritize polish fixes, blockers, warnings, and follow-up validation.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["playtest_report", "test_evidence"],
    cliAlias: "playtest-polish"
  }),
  "team-polish": workflow({
    id: "team-polish",
    model: "bitrouter/auto",
    modelReasoningEffort: "low",
    role: "producer",
    phase: "plan",
    category: "team-coordination",
    gapCoverage: ["team polish planning", "multi-role polish coordination"],
    objective: "Coordinate polish work across design, art, audio, UI, QA, and engineering with owners, cutlines, risks, and verification gates.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["production_milestone", "risk_register"],
    cliAlias: "team-polish"
  }),
  "patch-notes": workflow({
    id: "patch-notes",
    model: "bitrouter/auto",
    modelReasoningEffort: "low",
    role: "release-manager",
    phase: "implement",
    category: "release-hotfix",
    gapCoverage: ["patch notes", "player-facing release communication"],
    objective: "Draft and write docs/patch-notes.md with highlights, fixes, known issues, compatibility notes, validation evidence, and approval needs.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["release_notes"],
    cliAlias: "patch-notes"
  }),
  changelog: workflow({
    id: "changelog",
    model: "bitrouter/auto",
    modelReasoningEffort: "low",
    role: "release-manager",
    phase: "implement",
    category: "release-hotfix",
    gapCoverage: ["changelog", "developer-visible change record"],
    objective: "Prepare and write docs/changelog.md with grouped changes, fixes, migration notes, known issues, and verification evidence.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["release_notes"],
    cliAlias: "changelog"
  }),
  "launch-checklist": workflow({
    id: "launch-checklist",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "release-manager",
    phase: "ship",
    category: "release-hotfix",
    gapCoverage: ["launch checklist", "launch readiness coordination"],
    objective: "Prepare launch-day readiness checks across build, store, comms, rollback, support, monitoring, and final go/no-go decisions.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["ship_check", "release_notes", "test_plan"],
    cliAlias: "launch-checklist"
  }),
  "design-spec": workflow({
    id: "design-spec",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "senior-game-designer",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["feature specification", "design acceptance criteria"],
    objective: "Create or review a feature/design spec with rules, edge cases, implementation slices, and acceptance criteria.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["feature_spec", "economy_model", "difficulty_curve", "player_journey"],
    cliAlias: "design-spec"
  }),
  "game-feel-tuning": workflow({
    id: "game-feel-tuning",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "game-feel-designer",
    phase: "review",
    category: "design-architecture",
    gapCoverage: ["game-feel review", "tuning recommendations"],
    objective: "Review moment-to-moment feel, controls, feedback, pacing, and tuning risks with actionable changes.",
    templateIds: ["game_feel_tuning", "difficulty_curve"],
    cliAlias: "feel-review"
  }),
  "art-direction": workflow({
    id: "art-direction",
    model: "bitrouter/auto",
    modelReasoningEffort: "low",
    role: "senior-game-artist",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["art direction", "asset production planning"],
    objective: "Define art direction, visual constraints, asset list, production risks, and review criteria.",
    templateIds: ["art_direction", "art_bible"],
    cliAlias: "art-direction"
  }),
  "ui-ux-review": workflow({
    id: "ui-ux-review",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "ui-ux-designer",
    phase: "review",
    category: "localization-accessibility",
    gapCoverage: ["UX review", "accessibility-aware UI inspection"],
    objective: "Review UI flows, HUD/menu clarity, usability, onboarding, accessibility, and interaction risks.",
    templateIds: ["ui_ux_review", "ux_spec", "accessibility_requirements", "player_journey"],
    cliAlias: "ui-review"
  }),
  "production-milestone": workflow({
    id: "production-milestone",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "producer",
    phase: "plan",
    category: "team-coordination",
    gapCoverage: ["milestone planning", "production risk tracking"],
    objective: "Convert current project state into milestone goals, task slices, risks, owners, and verification gates.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["production_milestone", "risk_register"],
    cliAlias: "milestone"
  }),
  handoff: workflow({
    id: "handoff",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "studio-orchestrator",
    phase: "plan",
    category: "team-coordination",
    gapCoverage: ["role handoff", "next-action routing"],
    objective: "Summarize current state, route next work to the right role, identify blockers, and produce a concise handoff.",
    templateIds: ["handoff"],
    cliAlias: "handoff"
  }),
  review: workflow({
    id: "review",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "qa-playtester",
    phase: "review",
    category: "qa-testing",
    gapCoverage: ["general project review", "verification gap reporting"],
    objective: "Review the current project state and report blockers, warnings, and verification gaps as JSON."
  }),
  "ship-check": workflow({
    id: "ship-check",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "release-manager",
    phase: "ship",
    category: "release-hotfix",
    gapCoverage: ["ship readiness", "release blocker review"],
    objective: "Assess milestone readiness, package risk, validation status, and release blockers.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["ship_check", "release_notes", "risk_register"]
  }),
  onboard: workflow({
    id: "onboard",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "studio-orchestrator",
    phase: "plan",
    category: "onboarding-discovery",
    gapCoverage: ["project onboarding", "repository orientation"],
    objective: "Orient a contributor to the project goal, current stage, key files, active roles, and safest first actions.",
    extraContextFiles: ["design/gdd.md", "production/timeline.md"],
    templateIds: ["handoff", "pitch_document"],
    cliAlias: "start",
    cliAliases: ["onboard"]
  }),
  brainstorm: workflow({
    id: "brainstorm",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "creative-director",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["concept ideation", "creative option generation"],
    objective: "Generate bounded game ideas, feature variations, player fantasies, and tradeoff notes from the current project constraints.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["pitch_document", "player_journey", "art_bible", "sound_bible"],
    cliAlias: "brainstorm"
  }),
  prototype: workflow({
    id: "prototype",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "producer",
    phase: "plan",
    category: "implementation-planning",
    gapCoverage: ["prototype planning", "playable-loop slicing"],
    objective: "Plan the smallest playable prototype slice with owner roles, required assets, implementation tasks, and validation checks.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["vertical_slice_report", "technical_design", "risk_register"],
    cliAlias: "prototype"
  }),
  "architecture-decision": workflow({
    id: "architecture-decision",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "technical-director",
    phase: "plan",
    category: "design-architecture",
    gapCoverage: ["architecture decision records", "technical tradeoff capture"],
    objective: "Draft an architecture decision with context, options, selected direction, consequences, risks, and verification implications.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["adr", "technical_design", "architecture_traceability"],
    cliAlias: "architecture-decision"
  }),
  "architecture-review": workflow({
    id: "architecture-review",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "technical-director",
    phase: "review",
    category: "design-architecture",
    gapCoverage: ["architecture review", "technical risk review"],
    objective: "Review architecture, engine constraints, module boundaries, technical risks, and validation gaps for a proposed or existing feature.",
    templateIds: ["technical_design", "architecture_traceability"],
    cliAlias: "architecture-review"
  }),
  "create-epics": workflow({
    id: "create-epics",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "producer",
    phase: "plan",
    category: "implementation-planning",
    gapCoverage: ["epic creation", "roadmap decomposition"],
    objective: "Create production epics from the project goal with scope, owners, dependencies, risks, and acceptance signals.",
    extraContextFiles: ["design/gdd.md", "production/timeline.md"],
    templateIds: ["production_milestone", "risk_register"],
    cliAlias: "create-epics"
  }),
  "create-stories": workflow({
    id: "create-stories",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "producer",
    phase: "plan",
    category: "implementation-planning",
    gapCoverage: ["story breakdown", "implementation-ready task slicing"],
    objective: "Break an epic or feature into implementation-ready stories with role owner, files or artifacts to inspect, acceptance criteria, and verification gates.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["feature_spec"],
    cliAlias: "create-stories"
  }),
  "sprint-plan": workflow({
    id: "sprint-plan",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "producer",
    phase: "plan",
    category: "team-coordination",
    gapCoverage: ["sprint planning", "iteration commitment"],
    objective: "Plan the next sprint or iteration with committed goals, role assignments, risks, validation gates, and explicit non-goals.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["sprint_plan", "risk_register"],
    cliAlias: "sprint-plan"
  }),
  "sprint-status": workflow({
    id: "sprint-status",
    model: "bitrouter/auto",
    modelReasoningEffort: "low",
    role: "studio-orchestrator",
    phase: "review",
    category: "team-coordination",
    gapCoverage: ["sprint status", "blocker visibility"],
    objective: "Summarize sprint status, completed work, blockers, risks, next owners, and verification evidence without mutating task state.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["sprint_plan", "postmortem"],
    cliAlias: "sprint-status"
  }),
  "story-readiness": workflow({
    id: "story-readiness",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "producer",
    phase: "review",
    category: "team-coordination",
    gapCoverage: ["story readiness", "definition-of-ready review"],
    objective: "Review whether a story is ready for implementation by checking scope, owner role, context files, acceptance criteria, risks, and verification commands.",
    templateIds: ["feature_spec", "risk_register"],
    cliAlias: "story-readiness"
  }),
  "story-done": workflow({
    id: "story-done",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "qa-playtester",
    phase: "review",
    category: "team-coordination",
    gapCoverage: ["definition of done", "completion review"],
    objective: "Review whether a story is done by checking acceptance criteria, changed artifacts, verification evidence, risks, and follow-up ownership.",
    templateIds: ["test_evidence", "vertical_slice_report", "postmortem"],
    cliAlias: "story-done"
  }),
  "qa-plan": workflow({
    id: "qa-plan",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "qa-playtester",
    phase: "plan",
    category: "qa-testing",
    gapCoverage: ["test planning", "QA strategy"],
    objective: "Create a QA plan with target scenarios, risk areas, test data, manual checks, automated checks, and exit criteria.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["test_plan", "test_evidence", "accessibility_requirements"],
    cliAlias: "qa-plan"
  }),
  "regression-suite": workflow({
    id: "regression-suite",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "qa-playtester",
    phase: "review",
    category: "qa-testing",
    gapCoverage: ["regression suite planning", "test coverage review"],
    objective: "Design or review a regression suite for changed gameplay, UI, engine, content, and release-critical behavior.",
    templateIds: ["test_plan", "test_evidence"],
    cliAlias: "regression-suite"
  }),
  "security-audit": workflow({
    id: "security-audit",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "security-engineer",
    phase: "review",
    category: "qa-testing",
    gapCoverage: ["security review", "abuse-case inspection"],
    objective: "Review security, secrets, dependencies, online surfaces, abuse cases, and mitigation priorities for the project or feature.",
    cliAlias: "security-audit"
  }),
  "perf-profile": workflow({
    id: "perf-profile",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "performance-analyst",
    phase: "review",
    category: "qa-testing",
    gapCoverage: ["performance profiling", "optimization triage"],
    objective: "Plan or review performance profiling across frame time, memory, loading, asset cost, bottlenecks, and measurement evidence.",
    templateIds: ["test_evidence"],
    cliAlias: "perf-profile"
  }),
  "release-checklist": workflow({
    id: "release-checklist",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "release-manager",
    phase: "ship",
    category: "release-hotfix",
    gapCoverage: ["release checklist", "ship gate verification"],
    objective: "Create a release checklist with blockers, warnings, validation commands, packaging checks, rollback notes, and communication needs.",
    extraContextFiles: ["production/timeline.md"],
    templateIds: ["release_notes", "risk_register", "test_plan"],
    cliAlias: "release-checklist"
  }),
  hotfix: workflow({
    id: "hotfix",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "gameplay-programmer",
    phase: "review",
    category: "release-hotfix",
    gapCoverage: ["hotfix triage", "safe repair planning"],
    objective: "Triage a hotfix by identifying the minimal repair, risk surface, verification commands, rollback plan, and release communication notes.",
    templateIds: ["release_notes", "risk_register", "test_evidence"],
    cliAlias: "hotfix"
  }),
  "localization-plan": workflow({
    id: "localization-plan",
    model: "bitrouter/auto",
    modelReasoningEffort: "medium",
    role: "localization-lead",
    phase: "plan",
    category: "localization-accessibility",
    gapCoverage: ["localization planning", "culturalization readiness"],
    objective: "Create a localization plan with string scope, culturalization risks, asset dependencies, text expansion, subtitles, and verification checks.",
    extraContextFiles: ["design/gdd.md"],
    templateIds: ["accessibility_requirements", "ux_spec"],
    cliAlias: "localization-plan"
  }),
  "godot-implementation": workflow({
    id: "godot-implementation",
    model: "bitrouter/auto",
    modelReasoningEffort: "high",
    role: "godot-specialist",
    phase: "implement",
    category: "implementation-planning",
    gapCoverage: ["godot implementation", "MCP tooling", "scene verification"],
    objective: "Execute a bounded implementation slice in Godot using MCP tools, ensuring all changes are verified with visual/log evidence.",
    extraContextFiles: ["AGENTS.md", ".codex/studio.json"],
    cliAlias: "godot-implementation"
  })
}

export function workflowAliases(workflow: WorkflowDefinition): string[] {
  return [...new Set([workflow.cliAlias, ...(workflow.cliAliases ?? [])].filter((alias): alias is string => Boolean(alias)))];
}

function renderWorkflowTemplates(workflow: WorkflowId, projectRoot?: string): string {
  return renderSelectedTemplates(workflowRegistry[workflow].templateIds ?? [], "## Workflow Templates", projectRoot ? { projectRoot } : {});
}

function readBuiltInWorkflowBody(projectRoot: string, workflow: WorkflowId): string {
  const file = path.join(projectRoot, workflowRegistry[workflow].file);
  return existsSync(file) ? readFileSync(file, "utf8").trim() : `Workflow file missing: ${workflowRegistry[workflow].file}`;
}

function readStudioEngine(projectRoot: string): EngineId {
  return readWorkflowStudio(projectRoot).engine;
}

function readWorkflowStudio(projectRoot: string): Pick<StudioProjectState, "mode" | "studioMode" | "engine"> {
  const studioPath = path.join(projectRoot, ".codex", "studio.json");
  try {
    return JSON.parse(readFileSync(studioPath, "utf8")) as Pick<StudioProjectState, "mode" | "studioMode" | "engine">;
  } catch (error) {
    throw new Error(`${studioPath} could not be read as JSON: ${(error as Error).message}`);
  }
}

export function workflowIds(): WorkflowId[] {
  return Object.keys(workflowRegistry) as WorkflowId[];
}

export function workflowForAlias(alias: string): WorkflowDefinition | undefined {
  return Object.values(workflowRegistry).find((workflow) => workflowAliases(workflow).includes(alias));
}

export function renderWorkflowPrompt(projectRoot: string, workflow: string): string {
  const builtIn = workflowRegistry[workflow as WorkflowId];
  if (!builtIn) return renderCustomWorkflowPrompt(projectRoot, workflow);
  const config = builtIn;
  const studio = readWorkflowStudio(projectRoot);
  const selection = selectContextEntries(
    projectRoot,
    [
      ...config.contextFiles.map((sourcePath) => ({ sourcePath, reason: `workflow ${workflow} context`, required: true })),
      ...engineReferenceContextRequests(studio.engine, config.role, config.objective)
    ]
  );
  const eligibility = evaluateStudioRunEligibility({
    projectStage: studio.mode,
    studioMode: studio.studioMode,
    phase: config.phase
  });
  const session = createCodexStudioSession({
    projectRoot,
    role: config.role,
    phase: config.phase,
    objective: config.objective,
    engine: readStudioEngine(projectRoot),
    contextFiles: selection.selected.map((entry) => entry.sourcePath),
    allowFileEdits: eligibility.allowFileEdits,
    sandbox: eligibility.codexSandbox,
    writePolicy: eligibility.writePolicy,
    eligibility
  });
  return (
    renderCodexPrompt(
      {
        ...session,
        contextContract: renderContextContract({
          session,
          projectStage: studio.mode,
          studioMode: studio.studioMode,
          entries: selection.entries,
          readOnlyReview: config.phase === "review"
        })
      }
    ) +
    [
      "",
      `## Workflow Instructions: ${config.file}`,
      "",
      readBuiltInWorkflowBody(projectRoot, workflow as WorkflowId),
      renderWorkflowTemplates(workflow as WorkflowId, projectRoot)
    ].join("\n")
  );
}

function renderCustomWorkflowPrompt(projectRoot: string, workflowId: string): string {
  const workflow = findCustomWorkflow(projectRoot, workflowId);
  if (!workflow) throw new Error(`Unknown workflow "${workflowId}"`);
  if (isStudioRoleId(workflow.role)) return renderBuiltInRoleCustomWorkflowPrompt(projectRoot, workflow, workflow.role);
  const role = findCustomRole(projectRoot, workflow.role);
  if (!role) throw new Error(`Custom workflow "${workflow.id}" references unavailable role "${workflow.role}"`);
  const workflowPath = projectRelativePath(projectRoot, workflow.file);
  const workflowBody = workflowPath.ok && existsSync(workflowPath.full) ? readFileSync(workflowPath.full, "utf8").trim() : "Custom workflow file missing.";
  const studio = readWorkflowStudio(projectRoot);
  const selection = selectContextEntries(
    projectRoot,
    [
      { sourcePath: "AGENTS.md", reason: `custom workflow ${workflow.id} instructions`, required: true },
      { sourcePath: ".codex/studio.json", reason: `custom workflow ${workflow.id} project state`, required: true },
      { sourcePath: workflow.file, reason: `custom workflow ${workflow.id} workflow prompt`, required: true },
      { sourcePath: role.promptFile, reason: `custom workflow ${workflow.id} role prompt`, required: true },
      ...workflow.contextFiles.map((sourcePath) => ({ sourcePath, reason: `custom workflow ${workflow.id} context`, required: false }))
    ]
  );
  const eligibility = evaluateStudioRunEligibility({
    projectStage: studio.mode,
    studioMode: studio.studioMode,
    phase: workflow.phase
  });
  return [
    "# Codex Game Studio Custom Workflow",
    "",
    `Workflow ID: ${workflow.id}`,
    `Role: ${role.displayName}`,
    `Role ID: ${role.id}`,
    `Context Strategy: ${role.contextStrategy}`,
    `Phase: ${workflow.phase}`,
    `Project Root: ${projectRoot}`,
    `Objective: ${workflow.objective}`,
    `Engine: ${studio.engine}`,
    `Sandbox: ${eligibility.codexSandbox}`,
    `Write Policy: ${eligibility.writePolicy}`,
    `File Edits: ${eligibility.allowFileEdits ? "allowed" : "not allowed"}`,
    "",
    "## Context Files",
    selection.selected.length ? selection.selected.map((entry) => `- ${entry.sourcePath}`).join("\n") : "- None selected",
    "",
    `## Workflow Instructions: ${workflow.file}`,
    "",
    workflowBody,
    "",
    renderCustomRolePrompt(projectRoot, role),
    renderSelectedTemplates(workflow.templateIds, "## Workflow Templates", { projectRoot })
  ].join("\n");
}

function renderBuiltInRoleCustomWorkflowPrompt(projectRoot: string, workflow: CustomWorkflowDefinition, role: StudioRoleId): string {
  const workflowPath = projectRelativePath(projectRoot, workflow.file);
  const workflowBody = workflowPath.ok && existsSync(workflowPath.full) ? readFileSync(workflowPath.full, "utf8").trim() : "Custom workflow file missing.";
  const studio = readWorkflowStudio(projectRoot);
  const selection = selectContextEntries(projectRoot, [
    { sourcePath: "AGENTS.md", reason: `custom workflow ${workflow.id} instructions`, required: true },
    { sourcePath: ".codex/studio.json", reason: `custom workflow ${workflow.id} project state`, required: true },
    { sourcePath: workflow.file, reason: `custom workflow ${workflow.id} workflow prompt`, required: true },
    ...workflow.contextFiles.map((sourcePath) => ({ sourcePath, reason: `custom workflow ${workflow.id} context`, required: false })),
    ...engineReferenceContextRequests(studio.engine, role, workflow.objective)
  ]);
  const eligibility = evaluateStudioRunEligibility({
    projectStage: studio.mode,
    studioMode: studio.studioMode,
    phase: workflow.phase
  });
  const session = createCodexStudioSession({
    projectRoot,
    role,
    phase: workflow.phase,
    objective: workflow.objective,
    engine: readStudioEngine(projectRoot),
    contextFiles: selection.selected.map((entry) => entry.sourcePath),
    allowFileEdits: eligibility.allowFileEdits,
    sandbox: eligibility.codexSandbox,
    writePolicy: eligibility.writePolicy,
    eligibility
  });
  return [
    renderCodexPrompt({
      ...session,
      contextContract: renderContextContract({
        session,
        projectStage: studio.mode,
        studioMode: studio.studioMode,
        entries: selection.entries,
        readOnlyReview: workflow.phase === "review"
      })
    }),
    "",
    `## Workflow Instructions: ${workflow.file}`,
    "",
    workflowBody,
    renderSelectedTemplates(workflow.templateIds, "## Workflow Templates", { projectRoot })
  ].join("\n");
}
