import { execFileSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { describe, test } from "node:test";
import { expect } from "expect";

const repoRoot = process.cwd();

describe("prompt surface audit", () => {
  test("audits local and CCGS prompt surfaces with metadata, decisions, and tests", () => {
    const output = execFileSync(process.execPath, ["--import", "tsx", "scripts/audit-prompt-surfaces.ts", "--json"], { cwd: repoRoot, encoding: "utf8" });
    const report = JSON.parse(output) as { local: { agents: number; workflows: number; skills: number }; upstream: { agents: number; skills: number }; decisionLegend: string[]; rows: Array<{ localPath: string; sourcePath?: string; sourceHash?: string; decision: string; status: string; metadata: Record<string, boolean>; discoveryMetadata: { text: string; valid: boolean; diagnostics: Array<{ id: string; message: string }> }; requiredTests: string[] }> };
    expect(report.local.agents).toBeGreaterThanOrEqual(38);
    expect(report.local.workflows).toBeGreaterThanOrEqual(31);
    expect(report.local.skills).toBeGreaterThanOrEqual(79);
    // Upstream-dependent assertions (counts and per-row source mapping) depend on a
    // CCGS reference checkout (CCGS_ROOT, a sibling Claude-Code-Game-Studios checkout,
    // or the legacy /opt/data default). Gate only those so machines without the
    // checkout still verify local surfaces; the audit script resolves the same roots.
    const siblingUpstream = path.join(path.dirname(repoRoot), "Claude-Code-Game-Studios");
    const upstreamRoot =
      process.env.CCGS_ROOT || (existsSync(path.join(siblingUpstream, ".claude", "agents")) ? siblingUpstream : "/opt/data/repos/Claude-Code-Game-Studios");
    const upstreamAvailable = existsSync(path.join(upstreamRoot, ".claude", "agents"));
    if (upstreamAvailable) {
      expect(report.upstream.agents).toBeGreaterThanOrEqual(49);
      expect(report.upstream.skills).toBeGreaterThanOrEqual(73);
    }
    expect(report.decisionLegend).toEqual(["adopt", "adapt", "merge", "split", "defer", "out-of-scope"]);
    const prototype = report.rows.find((row) => row.localPath === ".agents/skills/cgs-prototype/SKILL.md");
    if (upstreamAvailable) {
      expect(prototype?.sourcePath).toBe(".claude/skills/prototype/SKILL.md");
      expect(prototype?.sourceHash).toMatch(/^[a-f0-9]{64}$/);
    }
    expect(["adapt", "adopt", "merge", "split", "defer", "out-of-scope"]).toContain(prototype?.decision);
    expect(prototype?.status).toMatch(/complete|needs-uplift|deferred/);
    expect(prototype?.metadata.model).toBe(true);
    expect(prototype?.discoveryMetadata.text).toContain("prototype");
    expect(prototype?.discoveryMetadata.valid).toBe(true);
    expect(prototype?.requiredTests).toContain("tests/validation.test.ts");
    const gameDesigner = report.rows.find((row) => row.localPath === ".codex/agents/game-designer.toml");
    if (upstreamAvailable) {
      expect(gameDesigner?.sourcePath).toBe(".claude/agents/game-designer.md");
    }
    expect(gameDesigner?.metadata.model).toBe(true);
    expect(gameDesigner?.discoveryMetadata.valid).toBe(true);
    const verticalSlice = report.rows.find((row) => row.localPath === ".codex/workflows/vertical-slice.md");
    expect(verticalSlice?.discoveryMetadata.text).toContain("slice");
    expect(verticalSlice?.discoveryMetadata.valid).toBe(true);
    expect(existsSync(path.join(repoRoot, "references", "prompt-surface-uplift-matrix.json"))).toBe(true);
    expect(readFileSync(path.join(repoRoot, "references", "prompt-surface-uplift-matrix.md"), "utf8")).toContain("cgs-prototype");
  });
});
